import { useState, useRef, useCallback } from "react";

interface AudioEntry {
  id: string;
  name: string;
  startMs: number;
  endMs: number;
  durationMs: number;
}

function msToSrtTime(ms: number): string {
  const h = Math.floor(ms / 3600000).toString().padStart(2, "0");
  const m = Math.floor((ms % 3600000) / 60000).toString().padStart(2, "0");
  const s = Math.floor((ms % 60000) / 1000).toString().padStart(2, "0");
  const msStr = (ms % 1000).toString().padStart(3, "0");
  return `${h}:${m}:${s},${msStr}`;
}

function msToDisplay(ms: number): string {
  const h = Math.floor(ms / 3600000).toString().padStart(2, "0");
  const m = Math.floor((ms % 3600000) / 60000).toString().padStart(2, "0");
  const s = Math.floor((ms % 60000) / 1000).toString().padStart(2, "0");
  return `${h}:${m}:${s}`;
}

const GAP_MS = 500;

async function getAudioDuration(file: File): Promise<number> {
  return new Promise((resolve) => {
    const audio = new Audio();
    const url = URL.createObjectURL(file);
    audio.preload = "metadata";
    audio.onloadedmetadata = () => {
      const dur = audio.duration;
      URL.revokeObjectURL(url);
      resolve(isFinite(dur) ? Math.round(dur * 1000) : 0);
    };
    audio.onerror = () => { URL.revokeObjectURL(url); resolve(0); };
    audio.src = url;
  });
}

export default function SrtMakerTab() {
  const [audioEntries, setAudioEntries] = useState<AudioEntry[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [sentences, setSentences] = useState("");
  const [generated, setGenerated] = useState(false);
  const [lang, setLang] = useState<"en" | "ar" | "de">("en");
  const [langOpen, setLangOpen] = useState(false);
  const langDir = lang === "ar" ? "rtl" : "ltr";
  const audioInputRef = useRef<HTMLInputElement>(null);
  const lineRefs = useRef<(HTMLInputElement | null)[]>([]);

  const processFiles = useCallback(async (files: File[]) => {
    const audioFiles = files.filter((f) =>
      f.type.startsWith("audio/") || /\.(mp3|wav|ogg|m4a|aac|flac|wma)$/i.test(f.name)
    );
    if (!audioFiles.length) return;
    audioFiles.sort((a, b) => a.name.localeCompare(b.name));
    setLoadingFiles(true);
    let cumulative = 0;
    const entries: AudioEntry[] = [];
    for (const file of audioFiles) {
      const durationMs = await getAudioDuration(file);
      entries.push({ id: `${file.name}-${file.size}`, name: file.name, startMs: cumulative, endMs: cumulative + durationMs, durationMs });
      cumulative += durationMs + GAP_MS;
    }
    setAudioEntries((prev) => {
      const existingIds = new Set(prev.map((e) => e.id));
      const combined = [...prev, ...entries.filter((e) => !existingIds.has(e.id))];
      let offset = 0;
      return combined.map((e) => { const s = offset; const end = s + e.durationMs; offset = end + GAP_MS; return { ...e, startMs: s, endMs: end }; });
    });
    setGenerated(false);
    setLoadingFiles(false);
  }, []);

  function handleDrop(e: React.DragEvent) { e.preventDefault(); setIsDragging(false); processFiles(Array.from(e.dataTransfer.files)); }
  function handleFileInput(e: React.ChangeEvent<HTMLInputElement>) { processFiles(Array.from(e.target.files || [])); e.target.value = ""; }

  function removeEntry(id: string) {
    setAudioEntries((prev) => {
      const filtered = prev.filter((e) => e.id !== id);
      let offset = 0;
      return filtered.map((e) => { const s = offset; const end = s + e.durationMs; offset = end + GAP_MS; return { ...e, startMs: s, endMs: end }; });
    });
    setGenerated(false);
  }

  const allLines = sentences === "" ? [""] : sentences.split("\n");

  function updateLine(i: number, val: string) {
    const next = [...allLines];
    next[i] = val;
    setSentences(next.join("\n"));
    setGenerated(false);
  }

  function handleLineKeyDown(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      const next = [...allLines];
      next.splice(i + 1, 0, "");
      setSentences(next.join("\n"));
      setTimeout(() => lineRefs.current[i + 1]?.focus(), 0);
    } else if (e.key === "Backspace" && allLines[i] === "" && allLines.length > 1) {
      e.preventDefault();
      const next = [...allLines];
      next.splice(i, 1);
      setSentences(next.join("\n"));
      setTimeout(() => lineRefs.current[Math.max(0, i - 1)]?.focus(), 0);
    }
  }

  function handleLinePaste(i: number, e: React.ClipboardEvent<HTMLInputElement>) {
    const text = e.clipboardData.getData("text");
    if (text.includes("\n")) {
      e.preventDefault();
      const pasted = text.split("\n").map((l) => l.replace(/^\d+[\.\)]\s*/, "").trim());
      const next = [...allLines];
      next.splice(i, 1, ...pasted);
      setSentences(next.join("\n"));
      setGenerated(false);
    }
  }

  const sentenceLines = sentences.split("\n").map((l) => l.replace(/^\d+[\.\)]\s*/, "").trim()).filter(Boolean);
  const srtCards = audioEntries.map((entry, i) => ({
    index: i + 1,
    startTime: msToSrtTime(entry.startMs),
    endTime: msToSrtTime(entry.endMs),
    text: sentenceLines[i] ?? "",
    name: entry.name,
  }));

  function handleDownload() {
    const content = srtCards.map((c) => `${c.index}\n${c.startTime} --> ${c.endTime}\n${c.text}`).join("\n\n");
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "output.srt"; a.click();
    URL.revokeObjectURL(url);
  }

  const canGenerate = audioEntries.length > 0 && sentenceLines.length > 0;
  const mismatch = audioEntries.length > 0 && sentenceLines.length > 0 && audioEntries.length !== sentenceLines.length;

  return (
    <div className="flex flex-col gap-3 h-full">
      <div className="flex items-center gap-2 flex-wrap">
        {mismatch && (
          <span className="flex items-center gap-1 text-xs bg-amber-100 text-amber-700 px-3 py-1.5 rounded-lg font-medium border border-amber-200">
            ⚠ {audioEntries.length} files · {sentenceLines.length} sentences
          </span>
        )}
        {!mismatch && audioEntries.length > 0 && sentenceLines.length > 0 && (
          <span className="text-xs bg-green-100 text-green-700 px-3 py-1.5 rounded-lg font-medium border border-green-200">
            ✓ {audioEntries.length} files matched
          </span>
        )}
        <div className="flex-1" />
        <button onClick={() => setGenerated(true)} disabled={!canGenerate}
          className="flex items-center gap-2 px-5 py-2 rounded-lg bg-orange-500 text-white text-sm font-semibold hover:bg-orange-600 disabled:opacity-40 disabled:cursor-not-allowed shadow transition-colors">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          Generate SRT
        </button>
        <button onClick={handleDownload} disabled={!generated || srtCards.length === 0}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed shadow transition-colors">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Download SRT
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4" style={{ height: "calc(100vh - 220px)", minHeight: 480 }}>

        {/* BOX 1 — Voice Input */}
        <div className="flex flex-col rounded-2xl border-2 border-green-200 overflow-hidden shadow-sm">
          <div className="bg-gray-50 border-b border-green-200 px-4 py-3 flex items-center gap-3 shrink-0">
            <span className="w-7 h-7 rounded-full bg-green-100 flex items-center justify-center text-green-600 text-sm font-bold">1</span>
            <div>
              <p className="text-gray-700 text-sm font-bold leading-none">Voice Input</p>
              <p className="text-gray-400 text-xs mt-0.5">MP3 / Audio files</p>
            </div>
            {audioEntries.length > 0 && (
              <button onClick={() => { setAudioEntries([]); setGenerated(false); }}
                className="ml-auto text-xs text-gray-400 hover:text-red-500 transition-colors">
                Clear all
              </button>
            )}
          </div>
          <div className="flex flex-col flex-1 overflow-hidden bg-white p-3 gap-3">
            <input ref={audioInputRef} type="file" accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac" multiple className="hidden" onChange={handleFileInput} />
            <div onClick={() => audioInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)} onDrop={handleDrop}
              className={`cursor-pointer rounded-xl border-2 border-dashed flex flex-col items-center justify-center py-5 px-3 select-none shrink-0 transition-all ${isDragging ? "border-green-400 bg-green-50" : "border-gray-200 hover:border-green-300 hover:bg-green-50/40"}`}>
              {loadingFiles ? (
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <svg className="w-4 h-4 animate-spin text-green-500" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  Reading durations...
                </div>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-2">
                    <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                    </svg>
                  </div>
                  <p className="text-sm font-semibold text-gray-600">Drop audio files</p>
                  <p className="text-xs text-gray-400 mt-0.5">MP3, WAV, M4A, OGG</p>
                </>
              )}
            </div>
            <div className="flex-1 overflow-y-auto flex flex-col gap-1.5">
              {audioEntries.map((entry, i) => (
                <div key={entry.id} className="flex items-center gap-2 bg-green-50 border border-green-100 rounded-lg px-3 py-2">
                  <span className="w-5 h-5 rounded-full bg-green-500 text-white text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-700 truncate">{entry.name}</p>
                    <p className="text-xs font-mono text-gray-400">{msToDisplay(entry.startMs)} → {msToDisplay(entry.endMs)}</p>
                  </div>
                  <button onClick={() => removeEntry(entry.id)} className="shrink-0 text-gray-300 hover:text-red-400 transition-colors">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
              {audioEntries.length > 0 && (
                <button onClick={() => audioInputRef.current?.click()}
                  className="text-xs text-green-600 hover:text-green-700 border border-dashed border-green-200 hover:border-green-400 rounded-lg py-1.5 transition-colors">
                  + Add more files
                </button>
              )}
            </div>
          </div>
        </div>

        {/* BOX 2 — Sentence Input */}
        <div className="flex flex-col rounded-2xl border-2 border-blue-200 overflow-hidden shadow-sm">
          <div className="bg-gray-50 border-b border-blue-200 px-3 py-2.5 flex items-center gap-2 shrink-0 flex-wrap">
            <span className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-sm font-bold shrink-0">2</span>
            <div className="shrink-0">
              <p className="text-gray-700 text-sm font-bold leading-none">Sentence Input</p>
              <p className="text-gray-400 text-xs mt-0.5">One sentence per line</p>
            </div>
            <div className="relative ml-2">
              <button
                onClick={() => setLangOpen((o) => !o)}
                title="Select language direction"
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-gray-200 bg-white text-xs font-bold text-gray-600 hover:border-blue-300 hover:text-blue-500 transition-all shadow-sm"
              >
                <span className="text-blue-500 font-semibold">{lang.toUpperCase()}</span>
                <svg className="w-3 h-3 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                  <circle cx="5" cy="12" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="19" cy="12" r="2" />
                </svg>
              </button>
              {langOpen && (
                <div className="absolute top-full left-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-50 overflow-hidden min-w-[110px]">
                  {([
                    { code: "en", label: "EN", desc: "English (LTR)" },
                    { code: "ar", label: "AR", desc: "Arabic (RTL)" },
                    { code: "de", label: "DE", desc: "German (LTR)" },
                  ] as const).map(({ code, label, desc }) => (
                    <button key={code} onClick={() => { setLang(code); setLangOpen(false); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold transition-colors hover:bg-blue-50 ${lang === code ? "bg-blue-50 text-blue-600" : "text-gray-600"}`}>
                      <span className="font-bold">{label}</span>
                      <span className="text-gray-400 font-normal">{desc}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 ml-auto">
              {sentences.trim() && (
                <>
                  <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full font-medium">{sentenceLines.length} lines</span>
                  <button onClick={() => { setSentences(""); setGenerated(false); }}
                    className="text-xs text-gray-400 hover:text-red-500 transition-colors font-medium">
                    Clear all
                  </button>
                </>
              )}
            </div>
          </div>
          <div className="flex flex-1 overflow-hidden bg-white p-3">
            <div className="flex-1 overflow-y-auto rounded-xl border border-gray-200 focus-within:ring-2 focus-within:ring-blue-300 bg-gray-50 px-3 py-2">
              {allLines.map((line, i) => (
                <div key={i} className="flex items-center min-h-[2rem]" dir={langDir}>
                  <span className="shrink-0 text-sm text-gray-700 font-mono"
                    style={{ userSelect: "none", WebkitUserSelect: "none", pointerEvents: "none", paddingInlineEnd: "6px" }}
                    aria-hidden="true">
                    {i + 1}.
                  </span>
                  <input ref={(el) => { lineRefs.current[i] = el; }} type="text" value={line}
                    onChange={(e) => updateLine(i, e.target.value)}
                    onKeyDown={(e) => handleLineKeyDown(i, e)}
                    onPaste={(e) => handleLinePaste(i, e)}
                    placeholder={i === 0 ? "Type or paste sentences here…" : ""}
                    className="flex-1 bg-transparent outline-none text-sm text-gray-700 font-mono placeholder-gray-300 py-1"
                    spellCheck={false} dir={langDir} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* BOX 3 — Output SRT */}
        <div className="flex flex-col rounded-2xl border-2 border-red-200 overflow-hidden shadow-sm">
          <div className="bg-gray-50 border-b border-red-200 px-4 py-3 flex items-center gap-3 shrink-0">
            <span className="w-7 h-7 rounded-full bg-red-100 flex items-center justify-center text-red-500 text-sm font-bold">3</span>
            <div>
              <p className="text-gray-700 text-sm font-bold leading-none">Output SRT</p>
              <p className="text-gray-400 text-xs mt-0.5">Preview &amp; download</p>
            </div>
            {generated && srtCards.length > 0 && (
              <span className="ml-auto text-xs bg-red-100 text-red-500 px-2 py-0.5 rounded-full font-medium">{srtCards.length} cards</span>
            )}
          </div>
          <div className="flex flex-col flex-1 overflow-hidden bg-white p-3">
            {!generated ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
                <div className="w-14 h-14 rounded-full bg-red-50 flex items-center justify-center mb-3">
                  <svg className="w-7 h-7 text-red-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <p className="text-sm font-semibold text-gray-400 mb-1">SRT output will appear here</p>
                <p className="text-xs text-gray-300">Add audio files &amp; sentences,<br />then click Generate SRT</p>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto flex flex-col gap-2">
                {srtCards.map((card) => (
                  <div key={card.index}
                    className={`rounded-xl border px-3 py-2.5 ${!card.text ? "border-amber-200 bg-amber-50/50" : "border-gray-200 bg-gray-50"}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold flex items-center justify-center shrink-0">{card.index}</span>
                      <span className="text-xs font-mono text-gray-400 truncate">{card.startTime} → {card.endTime}</span>
                      {!card.text && <span className="text-xs bg-amber-100 text-amber-600 px-1.5 rounded font-medium ml-auto">no text</span>}
                    </div>
                    <p className={`text-sm leading-snug pl-7 ${card.text ? "text-gray-800" : "text-gray-300 italic"}`}>
                      {card.text || "—"}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
